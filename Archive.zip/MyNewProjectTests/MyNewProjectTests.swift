//
//  MyNewProjectTests.swift
//  MyNewProjectTests
//
//  Created by Aitzhan Ramazan on 16.02.2025.
//

import Testing
@testable import MyNewProject

struct MyNewProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
