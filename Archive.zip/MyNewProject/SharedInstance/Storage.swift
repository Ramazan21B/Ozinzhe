//
//  Storage.swift
//  MyNewProject
//
//  Created by Aitzhan Ramazan on 19.03.2025.
//

import Foundation
import UIKit

class Storage{
    public var accessToken: String = ""
    static let sharedInstance = Storage()
}
