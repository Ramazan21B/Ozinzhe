//
//  ViewController.swift
//  MyNewProject
//
//  Created by Aitzhan Ramazan on 16.02.2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

